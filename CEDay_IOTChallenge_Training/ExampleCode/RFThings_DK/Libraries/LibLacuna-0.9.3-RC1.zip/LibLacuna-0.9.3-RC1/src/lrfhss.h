/*
 *  / _____)             _              | |
 * ( (____  _____ ____ _| |_ _____  ____| |__
 *  \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *  _____) ) ____| | | || |_| ____( (___| | | |
 * (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *    (C)2019 Semtech
 *
 * Description: LR-FHSS radio data types
 *
 * License: Revised BSD License, see LICENSE-SEMTECH.TXT file included in the project
 *
 * SPDX-License-Identifier: BSD-3-Clause
 *
 */

#ifndef __LRFHSS_H__
#define __LRFHSS_H__

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C"{
#endif

typedef enum {
	lsLrfhssCodingRate_5_6 = 0,
	lsLrfhssCodingRate_2_3 = 1,
	lsLrfhssCodingRate_1_2 = 2,
	lsLrfhssCodingRate_1_3 = 3
} lsLrfhssCodingRate;

typedef enum {
	lsLrfhssGrid_25_khz = 0,
	lsLrfhssGrid_3_9_khz = 1
} lsLrfhssGrid;

typedef enum {
	lsLrfhssBandwidth_39_06_khz = 0,
	lsLrfhssBandwidth_89_84_khz = 1,
	lsLrfhssBandwidth_136_7_khz = 2,
	lsLrfhssBandwidth_187_5_khz = 3,
	lsLrfhssBandwidth_335_9_khz = 4,
	lsLrfhssBandwidth_386_7_khz = 5,
	lsLrfhssBandwidth_722_6_khz = 6,
	lsLrfhssBandwidth_773_4_khz = 7,
	lsLrfhssBandwidth_1523_4_khz = 8,
	lsLrfhssBandwidth_1574_2_khz = 9
} lsLrfhssBandwidth;

/*! Datastructure containing parameters used when sending a LR-FHSS packet */
typedef struct {
	lsLrfhssCodingRate codingRate;           /*!< Coding rate */
	lsLrfhssBandwidth bandwidth;             /*!< Bandwidth */
	lsLrfhssGrid grid;                       /*!< Grid */
	bool hopping;                           /*!< Frequency hopping on or off. Note that frequency hopping is
                                                 not supported on the SX1276, and this parameter will be ignored */
	uint8_t nbSync;                         /*!< Number of header blocks */
	uint32_t frequency;                     /*!< Transmission frequency, in Hz */
	int8_t power;                           /*!< Transmission power */
} lsLoraSatTxParams;

#ifdef __cplusplus
} // extern "C"
#endif

#endif //__LRFHSS_H__
